<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Registration;
use Illuminate\Support\Facades\Crypt;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use App\User;

class RegistrationController extends Controller
{
    //
    public function index(Request $request)
    {
        # code...
        $registrations = Registration::select('*');
        if (isset($request["id"]) && $request["id"] != null) {
            $registrations = $registrations->where('id',$request["id"]);
        }
        if (isset($request["invitation_id"]) && $request["invitation_id"] != null) {
            $registrations = $registrations->where('invitation_id',$request["invitation_id"]);
        }
        $registrations = $registrations->get();

        return $registrations;
    }
    public function status(Request $request)
    {
        # code...
        $request =  json_decode(request()->getContent(), true);
        $registration = Registration::find($request["id"]);
        $registration->status = $request["status"];
        $registration->save();
        if($request["status"] == 1)
        {
            $qr = md5(Crypt::encryptString($registration->id+$registration->invitation_id)).md5("".$registration->invitation_id.$registration->id."");
            $registration->token = Crypt::encryptString($registration->id."-".$registration->invitation_id);
            QrCode::format('png')->size(500)->merge('/public/uploads/coto-logo.jpg', .3, false)->errorCorrection('H')->generate(Crypt::encryptString($registration->id."-".$registration->invitation_id), '../public/uploads/qrcodes/'.$qr.'.png');
            $registration->qr = '/uploads/qrcodes/'.$qr.'.png';
            $registration->save();
            $newUser = new User;
            $newUser->name = $registration->name;
            $newUser->phone = '52'.$registration->phone;
            $newUser->role_id = 5;
            $newUser->save();
        }

        return response()->json([
            'status' => 'OK'
        ]);

    }

    public function verifyqr(Request $request)
    {
        # code...
        $request =  json_decode(request()->getContent(), true);
        try {
        $qr = Crypt::decryptString($request["token"]);
        } catch(\Exception $e) {
            return response()->json([
                'error' => 'error de token',
                'code' => 'invalid token'
            ]);

        }
         $pos = strpos($qr,"-");
        if($pos === FALSE)
            $type = "new";
        else{
            $id = substr($qr,0,$pos);
            $user_id = substr($qr,$pos+1);
        }
        try {
            $registration = Registration::with('invitation')->where('id',$id)->get();
            $registration[0]->invitation->user;
            return $registration;
        }
        catch(\Exception $e) {
            return response()->json([
                'error' => 'error de registro',
                'code' => 'invalid registry'
            ]);

        }
    }
}
