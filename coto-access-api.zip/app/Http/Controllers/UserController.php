<?php

namespace App\Http\Controllers;

use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\UserCoto;

class UserController extends Controller
{
    public function index(Request $request)
    {
        # code...
        $user = User::find($request["user_id"]);

        $tenants = User::select('*')->where('coto_id',$user->coto_id)->where('role_id',$request["role_id"])->get();

        return $tenants;
    }
    //
    public function store(Request $request)
    {
        //
        $request =  json_decode(request()->getContent(), true);
        try{
            $coto = $request["coto"];
            try {
                foreach (json_decode($request["coto"], true) as $key => $value) {
                    # code...
                    $coto = $value["id"];
                }
            }
            catch(\Exception $e){
                //return $e;
            }

            $newUser = new User;
            $newUser->name = $request['name'];
            $newUser->phone = $request['phone'];
            $newUser->address = (isset($request['address']) ? $request['address'] : null);
            $newUser->nss = (isset($request['nss']) ? $request['nss'] : null);;
            $newUser->username = $request['username'];
            $newUser->password = Hash::make($request['password']);
            $newUser->role_id = $request['type'];
            $newUser->coto_id = $coto;
            $newUser->save();
            //$credentials = $request->only('email', 'password');
            //$token = JWTAuth::attempt($credentials);
            return response()->json([
                'status' => 'OK',
                'id' => $newUser->id,
                'user_role' => $newUser->role_id
            ]);
        } catch (\Illuminate\Database\QueryException $e) {
            $errorCode = $e->errorInfo[1];
            if($errorCode == 1062){
                return response()->json([
                    'error' => 'error de registro',
                    'code' => 'duplicated'
                ]);
            }
        } catch(\Exception $e) {
            return response()->json([
                'error' => 'error de registro',
                'code' => 'register'
            ]);

        }
    }

    public function authenticate(Request $request)
    {
        if(isset($request["phone"])) {
            $user = User::where('password',null)->where('phone',$request["phone"])->get();
            if($user->isEmpty()) {
                return response()->json([
                    'error' => 'No hay un usuario con esas credenciales'
                ]);
            }
            $user = $user[0];
        }
        else {
        $credentials = $request->only('username', 'password');

            try {
                // attempt to verify the credentials and create a token for the user
                if (! $token = JWTAuth::attempt($credentials)) {
                    return response()->json([
                        'error' => 'No hay un usuario con esas credenciales'
                    ]);
                }
            } catch (JWTException $e) {
                // something went wrong whilst attempting to encode the token
                return response()->json(['error' => 'could_not_create_token'], 500);
            }
            $user = JWTAuth::toUser($token);
        }

        $userInfo["id"] = $user->id;
        $userInfo["name"] = $user->name;
        $userInfo["phone"] = $user->phone;
        $userInfo['user_role'] = $user->role_id;

        return $userInfo;

        // all good so return the token
        //return response()->json(compact('token'));
    }

    public function test(Request $request)
    {
        # code...
        $data = [];
        $user = User::find(11);
        foreach($user->invitations as $value){
            $value->registrations;
        }
        return $user;
    }

    public function userToken(Request $request)
    {
        $request =  json_decode(request()->getContent(), true);
        $user = User::find($request["id"]);
        $user->fcm = $request["token"];
        $user->save();
        return response()->json([
            'status' => 'OK'
        ]);

    }
}
