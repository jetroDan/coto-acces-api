<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserCoto extends Model
{
    //
    protected $table = "user_coto";
}
