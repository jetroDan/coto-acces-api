<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::resource('users','UserController');
Route::resource('cotos','CotoController');
Route::resource('invitations','InvitationController');
Route::get('invitations_received','InvitationController@received');
Route::get('entries','InvitationController@entries');
Route::resource('registrations','RegistrationController');
Route::resource('notifications','NotificationController');
Route::post('registrations.status','RegistrationController@status');
Route::post('registrations.verifyqr','RegistrationController@verifyqr');
Route::post('image','InvitationController@uploadImage');
Route::post('register','InvitationController@register');
Route::post('test','InvitationController@test');
Route::get('login','UserController@authenticate');
Route::get('test','UserController@test');
Route::post('userToken','UserController@userToken');
